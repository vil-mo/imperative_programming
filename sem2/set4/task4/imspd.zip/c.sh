gcc regs.c -shared -fPIC -o core.so
